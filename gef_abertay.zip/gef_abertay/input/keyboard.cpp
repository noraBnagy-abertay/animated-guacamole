#include "keyboard.h"

namespace gef
{
	Keyboard::~Keyboard()
	{

	}

	bool Keyboard::IsKeyDown(KeyCode key) const
	{
		return false;
	}

	bool Keyboard::IsKeyPressed(KeyCode key) const
	{
		return false;
	}

	bool Keyboard::IsKeyReleased(KeyCode key) const
	{
		return false;
	}
}
