#include <audio/audio_manager.h>

namespace gef
{
	AudioManager::AudioManager()
	{

	}

	AudioManager::~AudioManager()
	{
	}
}