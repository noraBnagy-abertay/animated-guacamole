#include <graphics/depth_buffer.h>

namespace gef
{
	DepthBuffer::DepthBuffer(UInt32 height, UInt32 width) :
		height_(height),
		width_(width)
	{

	}

	DepthBuffer::~DepthBuffer()
	{

	}
}