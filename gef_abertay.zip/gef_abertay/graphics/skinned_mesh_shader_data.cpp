#include <graphics/skinned_mesh_shader_data.h>
#include <cstdlib>

namespace gef
{
	SkinnedMeshShaderData::SkinnedMeshShaderData() :
	bone_matrices_(NULL)
	{
	}
}

