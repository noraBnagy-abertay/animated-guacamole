#include <audio/audio_manager.h>
#include <cstddef> // for NULL definition

namespace gef
{
	AudioManager* AudioManager::Create()
	{
		return NULL;
	}
}