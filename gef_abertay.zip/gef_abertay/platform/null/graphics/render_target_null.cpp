#include <graphics/render_target.h>
#include <cstddef> // for NULL definition

namespace gef
{
	RenderTarget* RenderTarget::Create(const Platform& platform, Int32 width, Int32 height)
	{
		return NULL;
	}
}