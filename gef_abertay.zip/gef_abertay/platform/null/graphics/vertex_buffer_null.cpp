#include <graphics/vertex_buffer.h>
#include <cstddef> // for NULL definition

namespace gef
{
	VertexBuffer* VertexBuffer::Create(Platform& platform)
	{
		return NULL;
	}
}